(require '[tolglow.show :as show]
         '[tolglow.visualization.cue-pads-test :as tests]
         '[afterglow.control.devices.session :as session]
         '[clojure.test :as t])
(let [connect show/connect-device!
      suspend session/suspend!
      sent (atom []) received (atom 0) restoring? (atom false)
      fixture (fn [r k options]
                (let [send (get-in options [:midi :send!]) open (get-in options [:midi :open!])
                      midi (-> (:midi options)
                               (assoc :send! (fn [h frames]
                                               (when-not @restoring?
                                                 (swap! sent conj [@received frames]))
                                               (send h frames)))
                               (assoc :open! (fn [accept]
                                               (open (fn [f]
                                                       (when (and (= 4 (get f 6)) (= 240 (first f)))
                                                         (swap! received inc))
                                                       (accept f))))))]
                  (connect r k (assoc options :midi midi))))]
  (with-redefs [show/connect-device! fixture session/suspend! (fn [device] (reset! restoring? true) (suspend device))]
    (binding [t/*report-counters* (ref t/*initial-report-counters*)]
      (t/test-vars [#'tests/push-entry-point-previews-without-starting-a-cue-or-lighting-a-fixture])
      (let [result {:clock-ms 75 :replies @received :frames @sent :test @t/*report-counters*}]
        (when-not (and (= 128 @received) (zero? (apply + ((juxt :error :fail) (:test result)))))
          (throw (ex-info "MIDI replay failed" (dissoc result :frames))))
        (spit "/tmp/pad-overlap/fixed-palette.edn" (pr-str result))
        (prn (dissoc result :frames))))))
(shutdown-agents)
