(require '[tolglow.perf.weighted-venue :as venue] '[tolglow.bench-show :as bench] '[tolglow.show :as show]
         '[perf.original-beam :as old-beam] '[afterglow.spatial.beam :as beam] '[afterglow.spatial.field :as field] '[afterglow.spatial.geometry :as geometry] '[afterglow.time :as time]
         '[clojure.edn :as edn] '[clojure.string :as str])
(import '[java.lang.management ManagementFactory] '[java.security MessageDigest] '[java.util HexFormat]
        '[java.time Instant Duration] '[jdk.jfr Recording] '[jdk.jfr.consumer RecordingFile]
        '[java.nio.file Paths] '[java.io File])
(load-file (System/getenv "VENUE_MATERIAL_FILE"))
(defn old-vec3? [v] (and (vector? v) (= 3 (count v)) (every? time/finite-number? v)))
(def ^:dynamic *stages* nil)
(def stages
  {'afterglow.spatial/advance :physics
   'tolglow.spatial/advance :spatial
   'tolglow.spatial.cues/frame-fields :weighted-fields
   'afterglow.spatial.field/sample-volume :field
   'afterglow.runtime.engine/advance :engine
   'afterglow.render.frame/resolve-contributions :render
   'afterglow.render.layers/compose :layers})
(defn stage-wrapper [f stage]
  (fn [& args]
    (if-not *stages* (apply f args)
      (let [start (System/nanoTime)]
        (try (apply f args)
             (finally (swap! *stages* update stage (fnil + 0.0)
                             (/ (- (System/nanoTime) start) 1e6))))))))
(def wrappers
  (into {} (keep (fn [[sym stage]]
                   (when-let [v (resolve sym)] [v (stage-wrapper @v stage)]))) stages))

(defn epoch-ns [^Instant x]
  (+ (* (.getEpochSecond x) 1000000000) (.getNano x)))
(defn proc-text [path]
  (with-open [stream (java.io.FileInputStream. ^String path)]
    (String. (.readNBytes stream 4096) java.nio.charset.StandardCharsets/UTF_8)))
(defn clock-sample []
  (let [[cpu waiting] (map parse-long (str/split (str/trim (proc-text "/proc/thread-self/schedstat")) #"\s+"))
        stats (->> (str/split-lines (proc-text "/sys/fs/cgroup/cpu.stat"))
                   (map #(str/split % #" ")) (into {}))]
    {:main-cpu cpu :runqueue waiting :cgroup-throttled-ms (* 1000 (parse-long (stats "throttled_usec")))}))
(defn observations [f counters]
  (let [a (clock-sample) start-bytes ((:allocated counters)) start-cpu ((:cpu counters))
        begin (epoch-ns (Instant/now)) mono (System/nanoTime)
        stages (atom {}) result (binding [*stages* stages] (f)) wall (- (System/nanoTime) mono) end (epoch-ns (Instant/now))
        cpu-ms (/ (- ((:cpu counters)) start-cpu) 1e6) bytes (- ((:allocated counters)) start-bytes)
        b (clock-sample)]
    {:frame result :metrics (merge {:start begin :end end :ms (/ wall 1e6) :cpu-ms cpu-ms :bytes bytes}
                                   @stages (:stages-ms result) (update-vals (merge-with - b a) #(/ % 1e6)))}))
(defn pauses [path]
  (for [event (RecordingFile/readAllEvents path) :when (= "jdk.GCPhasePause" (.getName (.getEventType event)))]
    [(epoch-ns (.getStartTime event)) (epoch-ns (.getEndTime event))]))
(defn with-pauses [events {:keys [start end] :as row}]
  (assoc row :gc-pause-ms (/ (reduce + (map (fn [[a b]] (max 0 (- (min b end) (max a start)))) events)) 1e6)))
(defn rig-and-hosts []
  (let [pixels (parse-long (or (System/getenv "VENUE_PIXELS") "20000"))
        {:keys [model preview-indices]} (#'venue/venue pixels)
        shapes (venue/volumes 4 #{:position :beam} 0.0)
        model (#'venue/seed-model (mixed-chart-model model) shapes)
        owners (into {} (map (juxt :cue-id :id)) (vals (:instances model)))]
    {:ids (mapv #(owners (str "venue-field-" %)) (range 4))
     :preview-indices preview-indices
     :hosts [(#'venue/new-show model false) (#'venue/new-show model false)]
     :digest (MessageDigest/getInstance "SHA-256")}))

(defn separate-sampler [rig observations]
  #(field/sample % rig observations))

(defn advance-lane [{:keys [hosts ids preview-indices]} lane frame-number]
  (let [advance #(#'venue/host-step (hosts lane) ids preview-indices frame-number)]
    (if (= lane 0)
      (with-redefs [beam/contribution old-beam/contribution
                    geometry/vec3? old-vec3?
                    field/sampler separate-sampler]
        (advance))
      (advance))))

(defn capture-pair [{:keys [digest] :as rig} counters frame-number]
  (let [order (if (even? frame-number) [0 1] [1 0])
        capture (fn [lane]
                  (let [run #(advance-lane rig lane frame-number)]
                    [lane (if counters (observations run counters) {:frame (run)})]))
        results (into {} (map capture) order)
        reference (get-in results [0 :frame])]
    (bench/check! reference (get-in results [1 :frame]))
    (doseq [^bytes packet (:packets reference)]
      (.update ^MessageDigest digest packet))
    (mapv (fn [lane] (assoc (get-in results [lane :metrics])
                           :i frame-number :lane lane :order (.indexOf order lane)))
          [0 1])))

(defn record-frames [rig path warmup samples]
  (let [counters (#'bench/worker-counters)
        measure #(vec (mapcat (partial capture-pair rig counters) (range warmup (+ warmup samples))))]
    (with-open [recording (Recording.)]
      (.enable recording "jdk.GCPhasePause")
      (.start recording)
      (let [rows (with-redefs-fn wrappers measure)]
        (.stop recording)
        (.dump recording path)
        (let [events (vec (pauses path))]
          (mapv (partial with-pauses events) rows))))))

(defn replay [output warmup samples]
  (let [path (Paths/get (str output ".jfr") (make-array String 0))
        rig (rig-and-hosts)]
    (try
      (dotimes [i warmup] (capture-pair rig nil i))
      (let [rows (record-frames rig path warmup samples)]
        (spit output (pr-str {:mode "optics" :warmup warmup :samples samples
                              :artdmx-sha256 (.formatHex (HexFormat/of) (.digest ^MessageDigest (:digest rig)))
                              :rows rows})))
      (finally
        (doseq [host (:hosts rig)] (show/stop! (:runtime host)))
        (shutdown-agents)))))

(let [[output warmup samples] *command-line-args*]
  (replay output (parse-long warmup) (parse-long samples)))
