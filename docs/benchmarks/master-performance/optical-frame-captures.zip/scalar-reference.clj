(require '[tolglow.perf.weighted-venue :as venue] '[tolglow.bench-show :as bench] '[tolglow.show :as show])
(import '[java.security MessageDigest] '[java.util HexFormat])
(load-file (System/getenv "VENUE_MATERIAL_FILE"))
(let [pixels 20000 {:keys [model preview-indices]} (#'venue/venue pixels)
      model (#'venue/seed-model (mixed-chart-model model) (venue/volumes 4 #{:position :beam} 0.0))
      running (into {} (map (juxt :cue-id :id)) (vals (:instances model)))
      ids (mapv #(running (str "venue-field-" %)) (range 4))
      scalar (#'venue/new-show model true) candidate (#'venue/new-show model false)
      digest (MessageDigest/getInstance "SHA-256")]
  (try
    (dotimes [i 8]
      (let [expected (#'venue/host-step scalar ids preview-indices i)
            actual (#'venue/host-step candidate ids preview-indices i)]
        (bench/check! expected actual)
        (doseq [^bytes packet (:packets actual)] (.update digest packet))))
    (prn {:pixels pixels :movers 64 :frames 8 :universes 158 :packet-sha256 (.formatHex (HexFormat/of) (.digest digest))})
    (finally (doseq [host [scalar candidate]] (show/stop! (:runtime host))) (shutdown-agents))))
