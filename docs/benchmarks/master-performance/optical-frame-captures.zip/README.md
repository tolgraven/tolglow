# Mixed venue frame measurements

The Linux/JDK 21 run used 20,000 non-collinear RGBW pixels, 64 calibrated movers, four moving spheres with 0.5 m inner and 1 m outer falloff, receiver geometry and two show workers. Half of all fixtures have explicit UV coordinates. The other half use the world's X/Y as their material chart. A running shader reads both those UVs and world Z. Each host uses its own ArtDMX memory sink and a 25 ms logical period on the independent scheduler. The report contains a SHA-256 over packet emission order across both warmup and measured frames of the reference show. Every corresponding frame also compared model, intents, preview and all universe bytes.

## Replay

The replay scripts require Leiningen and JDK 21 on Linux with cgroup v2 CPU accounting and /proc/thread-self/schedstat. Set TOLGLOW_ROOT and AFTERGLOW_ROOT to absolute paths to checkouts containing the renderer and host changes. Run bash replay.sh /tmp/field-tail.edn. The reference optical code is read from Afterglow commit 4d96625 and loaded under a private Clojure namespace. The reference and candidate run in alternating order inside one JVM. The companion JFR file contains garbage collector pause intervals. The scalar comparison checks the complete frame using a one-worker scalar engine against a two-worker packed engine.

The captured mixed-material comparison used the Tolglow UV host 32dc6a77ea405978dd5e00b4621c8b90d9164e1d overlaid with the spatial host update in c2b4822. The ordinary sculpture comparison used Tolglow master 71ade9a. Afterglow started from 4d96625. The candidate adds per-frame emission reuse, allocation-free tuple validation and primitive radial contact math. The single-query arithmetic comparison applies the same predicate and math improvements without sharing emission snapshots.

## Files

- shared-mixed.edn contains 30 warmup pairs and all 40 measured pairs for the new sampler on the mixed material rig.
- scalar-mixed.edn contains a separate eight-frame scalar and packed comparison for the same fixture and cue layout.
- arithmetic-mixed.edn contains 28 warmup pairs and 32 measured pairs for the isolated optical arithmetic change.
- arithmetic-spatial.edn contains 40 warmup pairs and 48 measured pairs for the arithmetic change with the original venue material.
- previous-sphere-change.edn compares the preceding transformed-sphere optimization to its original inverse transform on Tolglow a0a2a32. This separately exercises the slow frames that prompted the follow-up.

## Measures

Each :rows entry records an index and lane (0 reference, 1 candidate), overall wall time, tick/publication/preview wall time, coordinator plus runtime-worker CPU and allocations. Individual :field, :spatial and :layers wall times are inclusive and overlap their callers. :runqueue is the coordinator's runnable wait from Linux schedstat. :gc-pause-ms is the exact overlap of the measured interval with JFR GCPhasePause events. :cgroup-throttled-ms is the shared cgroup throttle time delta in milliseconds. It includes other processes and cannot identify this show's scheduling delay.

These are measurements on a shared CPU with an observed 4-core quota. The phase and scheduler samples distinguish possible causes within each recorded frame. They cannot retrospectively identify why a frame was delayed in an earlier uninstrumented run.
