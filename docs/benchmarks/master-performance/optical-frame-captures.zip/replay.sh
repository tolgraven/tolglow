#!/usr/bin/env bash
set -euo pipefail
: "${TOLGLOW_ROOT:?Set an absolute path to the Tolglow checkout}"
: "${AFTERGLOW_ROOT:?Set an absolute path to the Afterglow checkout}"
capture_dir="$(cd "$(dirname "$0")" && pwd)"
capture_temp="$(mktemp -d)"
trap 'rm -rf "$capture_temp"' EXIT
mkdir -p "$capture_temp/perf"
baseline_ref=4d96625fc615ba6730275d02484efb9b4c384c34
git -C "$AFTERGLOW_ROOT" show "$baseline_ref:src/afterglow/spatial/beam.clj" |
  sed -e 's/^(ns afterglow.spatial.beam$/(ns perf.original-beam/' \
      -e 's/::prepared/:afterglow.spatial.beam\/prepared/g' \
      -e 's/::mounted/:afterglow.spatial.beam\/mounted/g' \
      -e 's/::probe/:afterglow.spatial.beam\/probe/g' >"$capture_temp/perf/original_beam.clj"
export AFTERGLOW_ROOT VENUE_MATERIAL_FILE="$capture_dir/mixed-material.clj"
class_path="$(cd "$TOLGLOW_ROOT" && lein with-profile +benchmark classpath)"
java_flags=(-Xms1100m -Xmx1100m -XX:ActiveProcessorCount=3 -cp "$capture_temp:$class_path")
java "${java_flags[@]}" clojure.main "$capture_dir/scalar-reference.clj"
java "${java_flags[@]}" clojure.main "$capture_dir/frame-tail.clj" "${1:-$PWD/field-tail.edn}" "${VENUE_WARMUP:-30}" "${VENUE_SAMPLES:-40}"
