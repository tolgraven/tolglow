(ns venue.kernel-probe)
(set! *warn-on-reflection* true)

(defn checked-buffer? [values] (instance? double/1 values))

(defn byte-store-helper! [^bytes destination index level]
  (aset-byte destination index (unchecked-byte level)))

(defn byte-store! [^byte/1 destination index level]
  (aset destination index (unchecked-byte level)))

(defn scale-helper! [^doubles values gain]
  (let [gain (double gain)]
    (dotimes [index (alength values)]
      (aset-double values index (* gain (aget values index))))))

(defn scale! [^double/1 values gain]
  (let [gain (double gain)]
    (dotimes [index (alength values)]
      (aset values index (* gain (aget values index))))))
