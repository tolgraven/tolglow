(require '[clojure.edn :as edn] '[clojure.java.io :as io])
(defn percentile [fraction rows]
  (let [values (vec (sort rows))]
    (values (dec (long (Math/ceil (* (count values) fraction)))))))
(defn summary [rows]
  (let [worst (last (sort-by :ms rows))
        p95 (nth (sort-by :ms rows) (dec (long (Math/ceil (* (count rows) 0.95)))))]
    {:median (into {} (for [k [:ms :bytes :cpu-ms :render :spatial :engine :publish :gc-pause-ms :runqueue]]
                       [k (percentile 0.50 (map k rows))]))
     :p95 (into {} (for [k [:ms :bytes :cpu-ms :render :spatial :engine :publish :gc-pause-ms :runqueue]]
                       [k (percentile 0.95 (map k rows))]))
     :p95-row (select-keys p95 [:i :ms :spatial :engine :render :publish :gc-pause-ms :runqueue :main-cpu :cpu-ms])
     :worst (select-keys worst [:i :ms :gc-pause-ms :runqueue :main-cpu :cpu-ms])
     :late (count (filter #(> (:ms %) 25.0) rows))}))
(doseq [file *command-line-args*]
 (let [data (edn/read-string (slurp file))]
  (prn :file file :sha (:artdmx-sha256 data) :traffic (:traffic data) :backends (mapv #(select-keys (:compute %) [:native-dispatches :cpu-fallbacks :deadline-fallbacks :session]) (:backends data)))
  (doseq [[k rows] (sort-by key (group-by :lane (:rows data)))]
    (prn :lane k (summary rows)))))
