#!/usr/bin/env bash
set -euo pipefail
: "${TOLGLOW_ROOT:?set to a Tolglow checkout at 39defcc0}"
: "${AFTERGLOW_ROOT:?set to an Afterglow checkout at c83375f}"
dir=$(cd "$(dirname "$0")" && pwd)
out=${1:-"$dir/replay"}
mkdir -p "$out/src/afterglow/render"
test "$(git -C "$AFTERGLOW_ROOT" rev-parse HEAD)" = c83375f354cfcee7add00f3e4445edbfa870b513
test "$(git -C "$TOLGLOW_ROOT" rev-parse HEAD)" = 39defcc0cbc65d216a806a7ca818f6895df3f4aa
git -C "$AFTERGLOW_ROOT" show 4769e27c4b803c7a4a9f8ed9cd010ae5ddc0039b:src/afterglow/render/presentation.clj > "$out/src/afterglow/render/presentation.clj"
git -C "$AFTERGLOW_ROOT" show 252e546cffc2ca1d146093c3cf24b6d06c45e84a:src/afterglow/spatial.clj > "$out/src/afterglow/spatial.clj"
git -C "$AFTERGLOW_ROOT" show 844198c6510e32be28b6b6e51cb07724d4e98a41:src/afterglow/render/frame.clj > "$out/old-frame.clj"
git -C "$AFTERGLOW_ROOT" show 844198c6510e32be28b6b6e51cb07724d4e98a41:src/afterglow/render/presentation.clj | sed '1s/afterglow.render.presentation/perf.original-publication/' > "$out/baseline-presentation.clj"
cp_entries=$(cd "$TOLGLOW_ROOT" && lein with-profile +benchmark,+native-gpu classpath)
export LIBGL_ALWAYS_SOFTWARE=1 MESA_SHADER_CACHE_DISABLE=true LP_NUM_THREADS=2
export VENUE_GPU_MS=60000 VENUE_MOVEMENT=cpu VENUE_WORKER_MS=5000 VENUE_MATERIAL_FILE="$dir/mixed-material.clj"
export VENUE_BASELINE_PRESENTATION="$out/baseline-presentation.clj" VENUE_ORIGINAL_FRAME="$out/old-frame.clj"
if [[ ${2:-combined} = membership ]]; then
  export VENUE_RECORD_FIELD="$dir/record-field.clj" VENUE_PIXELS=20000
  for trial in host-members host-member-into; do
    java -Xms1450m -Xmx1450m -XX:ActiveProcessorCount=3 -cp "$out/src:$cp_entries" clojure.main "$dir/$trial.clj" "$out/$trial.edn" 18 40
  done
  python3 "$dir/rows.py" "$out/host-members.edn" "$out/host-member-into.edn"
  exit
fi
for size in 10000 20000; do
  VENUE_PIXELS=$size java -Xms1450m -Xmx1450m -XX:ActiveProcessorCount=3 -cp "$out/src:$cp_entries" clojure.main "$dir/joint.clj" "$out/$size.edn" 16 36
done
java -cp "$cp_entries" clojure.main "$dir/report.clj" "$out/10000.edn" "$out/20000.edn"
