(defn- record-field [model physical sample frame key {:keys [volume values instance] :as entry}]
  (let [position (get-in physical [:signals key :position])
        volume (cond-> volume (and (= :ball (:shape volume)) position) (assoc :position position))
        spec (get-in instance [:definition :spatial-volume])
        {:keys [weights aims]} (coverage volume instance (:aim-at-volume? spec) sample)
        error (or (:error entry) (get-in model (into run-path [key :error])))
        paint (cond-> (select-keys values (keys (get-in instance [:definition :outputs])))
                (:aim-at-volume? spec) (assoc :aim :volume))
        view {:volume volume :cue-id (:cue-id instance) :instance-id (:id instance)
              :paint paint :affected-head-count (count weights)}]
    (cond-> (-> frame
                (update :groups into (group-rows model key entry weights))
                (assoc-in [:overrides (:id instance)] (select-keys values (keys (:sources spec))))
                (assoc-in [:members key] (set (keys weights)))
                (assoc-in [:views key] (cond-> view error (assoc :error error))))
      aims (assoc-in [:aims (:id instance)] aims))))

