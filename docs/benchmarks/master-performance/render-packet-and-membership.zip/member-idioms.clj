(require '[clojure.edn :as edn])
(import '[com.sun.management ThreadMXBean] '[java.lang.management ManagementFactory])
(defn fresh-members [weights]
  (persistent! (reduce-kv (fn [members id _] (conj! members id)) (transient #{}) weights)))

(defn reconcile [previous weights]
  (let [keep-current (fn [members id] (if (contains? weights id) members (disj members id)))
        survivors (reduce keep-current previous previous)]
    (reduce-kv (fn [members id _] (conj members id)) survivors weights)))

(defn reconcile-transient [previous weights]
  (let [keep-current (fn [members id] (if (contains? weights id) members (disj! members id)))
        add-current (fn [members id _] (if (contains? previous id) members (conj! members id)))
        survivors (reduce keep-current (transient previous) previous)]
    (persistent! (reduce-kv add-current survivors weights))))

(def ^ThreadMXBean counters (ManagementFactory/getThreadMXBean))
(defn measure [f]
  (let [cpu (.getCurrentThreadCpuTime counters) bytes (.getCurrentThreadAllocatedBytes counters)
        result (f)]
    [result {:us (/ (- (.getCurrentThreadCpuTime counters) cpu) 1e3)
             :bytes (- (.getCurrentThreadAllocatedBytes counters) bytes)}]))
(defn case-trials [old weights samples]
  (let [prev (set old)
        expected (set (keys weights))
        runs [#(set (keys weights)) #(fresh-members weights) #(into #{} (map key) weights) #(into #{} (keys weights))]
        measure-all (fn [i]
                      (mapv (fn [lane]
                              (let [[actual metric] (measure (runs lane))]
                                (assert (= expected actual))
                                (assoc metric :lane lane)))
                            (if (even? i) [0 1 2 3] [3 2 1 0])))]
    (dotimes [i 18] (measure-all i))
    (vec (mapcat measure-all (range samples)))))
(let [ids (mapv #(if (even? %) (keyword (str "pixel-" %)) (str "pixel-" %)) (range 16000))
      weights (zipmap (subvec ids 0 8000) (map #(/ (mod % 257) 256.0) (range 8000)))
      cases [[:stable (subvec ids 0 8000)] [:slide32 (subvec ids 32 8032)] [:turnover (subvec ids 8000 16000)] [:no-prior []] [:small-previous (subvec ids 0 16)]]
      rows (into {} (for [[id previous] cases] [id (case-trials previous weights 36)]))]
  (spit (first *command-line-args*) (pr-str rows))
  (doseq [[scenario cases] rows]
    (prn scenario (for [[lane rows] (sort-by key (group-by :lane cases))]
                    [lane (into {} (map (fn [k] [k (nth (sort (map k rows)) 17)]) [:us :bytes]))]))))
