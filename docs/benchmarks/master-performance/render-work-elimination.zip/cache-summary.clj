(require '[clojure.edn :as edn])
(let [r (edn/read-string (slurp (first *command-line-args*)))
      q (fn [xs p] (double (nth (sort xs) (dec (int (Math/ceil (* p (count xs))))))))]
  (prn (select-keys r [:samples :warmup :heads :budget-ms :artdmx-sha256]))
  (doseq [[lane capacity] (map-indexed vector (:capacities r))]
    (let [rows (map #(nth % lane) (:rows r))
          before (get-in r [:before lane :compute :session])
          after (get-in r [:after lane :compute :session])]
      (prn {:capacity capacity :cold-frame (get-in r [:cold lane :ms])
            :p50 (q (map :ms rows) 0.5) :p95 (q (map :ms rows) 0.95)
            :cpu (q (map :cpu-ms rows) 0.5) :bytes (q (map :bytes rows) 0.5)
            :warm (into {} (for [k [:draws :hits :misses :evictions]] [k (- (k after) (k before))]))
            :fallbacks (get-in r [:after lane :compute :cpu-fallbacks])
            :residents (:resident after) :buffers (get-in r [:after lane :resident-buffers])}))))
