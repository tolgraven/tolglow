# Dense-rig renderer measurements, November 23, 2026

The workload runs Tolglow's production show, two-worker engine and independent output scheduler with a capture sink. The rig has 20,000 RGBW pixels on twisted strips, 64 mounted moving heads and 158 ArtDMX universes. Half the fixtures have explicit surface UVs. The other half use world X/Y. Four animated sphere fields combine position and beam selection. The packed-write and uniform-GPU comparisons add eight concurrent washes, except for the no-wash control.

Each whole-show pair compares the complete model, intents and every ArtDMX packet byte before accepting the observations. The preview oracle compares selected fixture values with an absolute tolerance of 1e-9. The native-isolation test separately compares every component of every returned array exactly. See the renderer work-elimination document in the containing repository for results and limitations.

## Replay

Use JDK 21, Leiningen and Linux with cgroup v2 and /proc/thread-self/schedstat. Native runs need desktop OpenGL. This capture used Mesa 25.0.7 llvmpipe, two software rasterizer threads and three JVM-visible CPUs. Production packets stay in memory. The Studio replay opens two loopback WebSocket clients. No physical output or device is needed.

Set TOLGLOW_ROOT and AFTERGLOW_ROOT to absolute checkout paths. Tolglow source for the timing runs was 8f4db26aa35a04d6ed53e9fe2f3a9cbcbc2a30d1. Afterglow e8867f0497f8e47e6e8701b5ebf6bc57d4b695c4 includes the packed-write pass. b711ae030624053d5529832e4b1acd602fb9c2da also includes native uniform broadcast. The rejected optical bound is available on branch codex/prune-dominated-beam-weights at 812481f1e80bcb1d119254d77ddc2185b77923b5. Its separate worktree must contain its parent d11a4c49824f137f0808bc95b4d20a746a8f6039 so the runner can load the reference beam/field algorithms.

| Report | Command after unpacking |
| --- | --- |
| packed-writes-cpu.edn | bash replay.sh packed packed.edn 15 24 |
| packed-writes-no-washes.edn | VENUE_WASHES=0 bash replay.sh packed no-washes.edn 15 24 |
| packed-writes-native.edn | VENUE_GPU_MS=2000 bash replay.sh packed packed-native.edn 12 16 |
| uniform-native.edn | VENUE_GPU_MS=2000 bash replay.sh uniform uniform.edn 18 24 |
| uniform-deadline.edn | VENUE_GPU_MS=12 bash replay.sh uniform deadline.edn 3 4 |
| capacity.edn | VENUE_GPU_MS=10000 bash replay.sh cache capacity.edn 12 18 |
| uniform-isolated.edn | bash replay.sh isolated isolated.edn |
| native-float32-vs-scalar.edn | bash replay.sh precision precision.edn |
| connected-studio.edn | bash replay.sh connected connected.edn |
| optical-bound-cpu.edn | bash replay.sh optical-bound bound.edn 15 24 |
| optical-bound-native.edn | VENUE_GPU_MS=2000 bash replay.sh optical-bound-native bound-native.edn 4 6 |

For Linux without an existing graphical session, prefix native commands with xvfb-run -a. Set LIBGL_ALWAYS_SOFTWARE=1 and LP_NUM_THREADS=2 to reproduce the software driver. The native replay used MESA_SHADER_CACHE_DISABLE=true for uniform groups. Run tests separately from a timed replay on an otherwise idle target when measuring hardware throughput.

Run the packed scenarios at the packed-write merge, the uniform scenarios at the uniform merge, and the optical-bound scenarios on the experimental branch above. For the repeated optical-frame timing in optical-repeat.edn, use replay.sh in the earlier optical-frame-captures.zip at the Tolglow and Afterglow merged revisions 1241761c58f25e16e5a271452804a74fb7e17dde and 6d1c39ac90ab860db3b8929938876387d7dd2cbb. Connected-studio used that optical implementation without the eight extra washes. Replays on newer revisions can change timings and sometimes numeric results.

The reference show runs first on even musical frame numbers. The candidate runs first on odd frames. Each has its own compiled programs, show and captured output. Timing includes host tick, commit and encoded output, with the explicit oracle comparison outside the recorded interval. The per-frame :rows contain lane 0 (reference) and lane 1 (candidate). For a report with paired rows, run bb summary.clj reports/uniform-native.edn or use clojure.main with the same script. The :artdmx-sha256 covers warmup plus measured packets of the reference in order. Diagnostic per-frame coverage and traffic counts come from one extra untimed frame after the digest. Historical packed-writes-cpu.edn was captured before adding that counter. Raw one-lane Studio and native-isolation reports use their own schemas.

The :bytes and :cpu-ms metrics describe the coordinator and show-worker threads measured by the host harness. They do not measure GPU-driver CPU, power consumption or actual PCIe bandwidth. Native readback bytes come from submitted vertex count times the compiled transform-feedback stride times four. The JFR GC overlap and Linux coordinator run-queue values are captured per frame. Differences between separately scheduled wall-time distributions cannot establish the cause of an older isolated spike.


The capacity replay uses an 8-slot reference and 16-/32-slot candidates in rotating order. All three run Afterglow b711ae0 and identical uniforms; the cold first frame and separately warmed rows and resource counters are included. Run bb cache-summary.clj reports/capacity.edn to inspect warm misses, draws, CPU and elapsed time. The saved resident bytes describe the frame-end vertex/feedback/readback buffers only. They exclude driver programs, retained output arrays, peak memory and compile scratch. A separate cold diagnostic at a two-second budget records which expressions and movers used CPU fallback in cold-deadline-mismatch.edn. The actual timed ten-second run completed every request natively. The capacity runner also writes an adjacent .primer file with the 1,000-pixel control.

The integration-worker-deadlines.edn file records two later exact default-budget failures on newer Tolglow checkouts. VENUE_WORKER_MS optionally overrides the ordinary worker deadline in the packed replay for a separately labelled parity diagnostic. An override does not establish that the default met its deadline.
