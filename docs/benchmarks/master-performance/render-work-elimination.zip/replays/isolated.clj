(require '[afterglow.render.gpu.expressions :as gpu])
(import '[java.util Arrays] '[java.lang.management ManagementFactory])
(def cpu-bean (ManagementFactory/getThreadMXBean))
(defn measure [runner env]
  (let [cpu (.getCurrentThreadCpuTime cpu-bean)
        t (System/nanoTime)
        result (gpu/evaluate! runner env)]
    {:result result :wall-ms (/ (- (System/nanoTime) t) 1e6)
     :caller-cpu-ms (/ (- (.getCurrentThreadCpuTime cpu-bean) cpu) 1e6)}))
(defn same! [a b]
  (assert (= (:count a) (:count b)))
  (assert (= (keys (:outputs a)) (keys (:outputs b))))
  (doseq [[id {:keys [values]}] (:outputs a)]
    (assert (Arrays/equals ^doubles values ^doubles (get-in b [:outputs id :values])))))
(defn scenario [outputs positions uvs]
  (let [open #(gpu/open! outputs positions {:surface-uvs uvs})]
    (with-open [reference (with-redefs-fn {#'gpu/draw-count (fn [_ heads] heads)} open)
                candidate (open)]
      (let [run (fn [i]
                  (let [v (/ (bit-and 255 i) 256.0) env {:params {:wash [0.25 v 0.125] :focus v}}
                        order (if (even? i) [reference candidate] [candidate reference])
                        [x y] (mapv #(measure % env) order)]
                    (same! (:result x) (:result y))
                    (mapv #(dissoc % :result) (if (even? i) [x y] [y x]))))
            traffic (fn [runner] (let [{:keys [vertices plan]} (:resources runner)]
                                   {:vertices vertices :bytes (* 4 vertices (:stride plan))}))]
        (dotimes [i 24] (run i))
        {:rows (mapv run (range 24 72)) :traffic (mapv traffic [reference candidate])}))))
(let [[out] *command-line-args*
      n 20000 p (mapv (fn [i] [(/ i 20000.0) (mod i 7) (* -0.5 i)]) (range n))
      uv (mapv (fn [i] (when (odd? i) [(/ i 20000.0) 0.75])) (range n))
      uniform {:color {:op :param :type :vec3 :key :wash} :focus {:op :param :key :focus}}
      spatial (assoc uniform :extra {:op :surface-uv :axis :v})]
  (spit out (pr-str {:warmup 24 :samples 48 :heads n :uniform (scenario uniform p nil)
                     :mixed-uv (scenario spatial p uv) :empty (scenario uniform [] nil)})))
