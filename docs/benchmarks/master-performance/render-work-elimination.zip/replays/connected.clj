(require '[tolglow.perf.weighted-venue :as venue] '[tolglow.bench-show :as bench]
         '[tolglow.bench-subscribers :as subs] '[tolglow.show :as show])
(import '[jdk.jfr Recording Configuration] '[java.nio.file Path])
(load-file (System/getenv "VENUE_MATERIAL_FILE"))
(let [{:keys [model preview-indices]} (#'venue/venue 20000)
      model (#'venue/seed-model (mixed-chart-model model) (venue/volumes 4 #{:position :beam} 0.0))
      running (into {} (map (juxt :cue-id :id)) (vals (:instances model)))
      ids (mapv #(running (str "venue-field-" %)) (range 4))
      clock (volatile! 0.0)
      original-step bench/host-step!
      original-create show/create-runtime
      create! (fn [opts] (original-create (cond-> (assoc opts :physical-now-ms #(deref clock))
                                            (false? (:batch? opts)) (assoc :worker-timeout-ms 10000)
                                            (not (false? (:batch? opts))) (assoc :independent-output? true))))
      recording (Recording. (Configuration/getConfiguration "profile"))
      _ (.enable recording "jdk.ObjectAllocationSample")
      advance! (fn [runtime sink indices i]
                 (when (and (:independent-output? runtime) (= i 2)) (.start recording))
                 (let [move! (fn [id shape] (show/submit! runtime {:op :param/set :param :position :instance-id id
                                               :command-id (str "move-" id "-" i) :value (:position shape)}))
                       receipts (mapv move! ids (venue/volumes 4 #{:position} (/ i 20.0)))]
                   (vreset! clock (* 25.0 (inc i)))
                   (vreset! (:latest sink) [])
                   (let [frame (original-step runtime sink indices i)]
                     (#'venue/accepted! receipts)
                     (assert (= 158 (count (:packets frame))))
                     (assert (not-any? :fault (vals (get-in frame [:model :instances]))))
                     (when (and (:independent-output? runtime) (= i 5))
                       (.stop recording)
                       (.dump recording (Path/of (str (first *command-line-args*) ".jfr") (make-array String 0))))
                     frame)))
      opts {:workers 2 :warmup 2 :samples 4 :period-ms 25}
      corpus {:model model :preview-indices preview-indices}]
  (try
    (with-redefs [show/create-runtime create! bench/host-step! advance!]
      (let [expected (#'subs/run-oracle corpus opts)
            result (#'subs/profile-case corpus expected 1 opts)]
        (spit (first *command-line-args*) (pr-str result))
        (prn (select-keys result [:rig-targets :visible-output-targets :host-tick-ms :ticks-over-period :slow-client]))))
    (finally (.close recording) (shutdown-agents))))
