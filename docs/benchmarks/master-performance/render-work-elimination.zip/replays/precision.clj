(require '[tolglow.perf.weighted-venue :as venue] '[tolglow.bench-show :as bench] '[tolglow.show :as show])
(load-file (System/getenv "VENUE_MATERIAL_FILE"))
(defn layers [model]
  (reduce (fn [m i]
            (let [id (keyword (str "wash-" i))
                  d {:id id :version 1 :outputs {:color [(/ (inc i) 21.0) 0.18 0.37] :white (/ (inc i) 20.0)}}]
              (-> m (bench/command [id :publish] {:op :registry/publish :kind :effects :definition d})
                  (bench/command [id :cue] {:op :cue/put :cue {:id id :effect-id id :priority (+ 20 i)}})
                  (bench/command [id :play] {:op :cue/launch :cue-id id})))) model
          (range (parse-long (or (System/getenv "VENUE_WASHES") "8")))))

(let [pixels 20000 {:keys [model preview-indices]} (#'venue/venue pixels)
      model (#'venue/seed-model (layers (mixed-chart-model model)) (venue/volumes 4 #{:position :beam} 0.0))
      running (into {} (map (juxt :cue-id :id)) (vals (:instances model)))
      ids (mapv #(running (str "venue-field-" %)) (range 4))
      scalar (#'venue/new-show model true)
      create! show/create-runtime
      candidates (mapv (fn [budget]
                         (with-redefs [show/create-runtime #(create! (assoc % :compute-backend :native-gpu :movement-backend :native-gpu :gpu-budget-ms budget))]
                           (#'venue/new-show model false))) [12 2000])
      reports (atom [])]
  (try
    (dotimes [i 6]
      (let [expected (#'venue/host-step scalar ids preview-indices i)]
        (doseq [[budget host] (map vector [12 2000] candidates)]
          (let [actual (#'venue/host-step host ids preview-indices i)
                comparisons (mapv (fn [^bytes l ^bytes r]
                                    (assert (= (alength l) (alength r)))
                                    (reduce (fn [[changed peak] idx]
                                              (let [d (abs (- (bit-and 255 (aget l idx)) (bit-and 255 (aget r idx))))]
                                                [(if (zero? d) changed (inc changed)) (max peak d)]))
                                            [0 0] (range 18 (alength l)))) (:packets expected) (:packets actual))
                _ (assert (= 158 (count comparisons)))
                deltas (mapcat (fn [l r] (map #(abs (- %1 %2)) (:emitted-color l) (:emitted-color r)))
                               (:preview expected) (:preview actual))]
            (assert (= (:intents expected) (:intents actual)))
            (swap! reports conj {:i i :budget budget :matching-model? (= (:model expected) (:model actual))
                                 :changed-dmx-slots (reduce + (map first comparisons))
                                 :max-dmx-step (reduce max (map second comparisons))
                                 :max-preview-color-error (reduce max 0.0 deltas)})))))
    (spit (first *command-line-args*) (pr-str {:rows @reports
          :backends (mapv (fn [{:keys [runtime]}] (select-keys (:status (show/snapshot runtime)) [:compute :movement])) candidates)}))
    (finally (doseq [host (cons scalar candidates)] (show/stop! (:runtime host))) (shutdown-agents))))
