(require '[tolglow.bench-show :as show-bench])
(defn mixed-chart-model [model]
  (let [place (fn [i fixture]
                (cond-> fixture (even? i)
                  (assoc :surface-uv [(/ (mod i 113) 112.0) (/ (mod i 17) 16.0)])))
        fixtures (mapv place (range) (get-in model [:rig :fixtures]))
        material {:id :projected-white :version 1 :params {} :outputs {:white 0.0}
                  :prefabs {:rig/chart {:mode :replace :glsl "0.5 + 0.1 * sin(world.z) + 0.2 * sin(uv.x) + 0.15 * sin(uv.y)"}}
                  :blocks {[:outputs :white] {:stages [{:block :rig/chart}]}}}]
    (-> model
        (assoc-in [:rig :fixtures] fixtures)
        (show-bench/command :chart-material {:op :registry/publish :kind :effects :definition material})
        (show-bench/command :chart-cue {:op :cue/put :cue {:id :chart :effect-id :projected-white}})
        (show-bench/command :chart-launch {:op :cue/launch :cue-id :chart}))))
