(require '[tolglow.perf.weighted-venue :as venue]
         '[tolglow.bench-show :as bench]
         '[tolglow.show :as show]
         '[afterglow.render.gpu.session :as session])
(import '[java.security MessageDigest] '[java.util HexFormat])
(load-file (System/getenv "VENUE_MATERIAL_FILE"))

(defn add-wash [model i]
  (let [id (keyword (str "wash-" i))
        outputs {:color [(/ (inc i) 21.0) 0.18 0.37] :white (/ (inc i) 20.0)}]
    (-> model
        (bench/command [id :publish] {:op :registry/publish :kind :effects
                                      :definition {:id id :version 1 :outputs outputs}})
        (bench/command [id :cue] {:op :cue/put :cue {:id id :effect-id id :priority (+ 20 i)}})
        (bench/command [id :play] {:op :cue/launch :cue-id id}))))

(defn open-host [model budget capacity]
  (let [create! show/create-runtime
        options {:compute-backend :native-gpu :movement-backend :native-gpu
                 :gpu-budget-ms budget :gpu-options {:max-programs capacity}}]
    (with-redefs [show/create-runtime #(create! (merge % options))]
      (#'venue/new-show model false))))

(defn statuses [hosts]
  (mapv (fn [{:keys [runtime]}]
          (let [status (:status (show/snapshot runtime))
                session (get-in runtime [:compute :session])
                programs @(#'session/enqueue! session
                            #(vec (.values ^java.util.LinkedHashMap (:programs session))))
                resident-bytes (fn [{:keys [vertices plan]}]
                                 (let [vertex-bytes (if (:surface-uv (:inputs plan)) 20 12)
                                       feedback-bytes (* vertices 4 (:stride plan))]
                                   {:vertex (* vertices vertex-bytes) :feedback feedback-bytes
                                    :host-readback feedback-bytes}))]
            {:compute (:compute status) :movement (:movement status)
             :resident-buffers (reduce (partial merge-with +) {} (map resident-bytes programs))})) hosts))

(defn measured-step [host ids indices frame counters]
  (let [cpu ((:cpu counters)) alloc ((:allocated counters)) t (System/nanoTime)
        output (#'venue/host-step host ids indices frame)]
    {:output output :metrics {:ms (/ (- (System/nanoTime) t) 1e6)
                              :cpu-ms (/ (- ((:cpu counters)) cpu) 1e6)
                              :bytes (- ((:allocated counters)) alloc)}}))

(defn frame [hosts ids indices n counters ^MessageDigest digest]
  (let [order (take 3 (drop (mod n 3) (cycle (range 3))))
        rows (into {} (map (fn [lane] [lane (measured-step (hosts lane) ids indices n counters)]) order))
        reference (get-in rows [0 :output])]
    (doseq [lane [1 2]]
      (let [actual (get-in rows [lane :output])]
        (try
          (bench/check! reference actual)
          (catch Exception e
            (let [packet-deltas
                  (for [[u [^bytes a ^bytes b]] (map-indexed vector (map vector (:packets reference) (:packets actual)))
                        idx (range (alength a)) :when (not= (aget a idx) (aget b idx))]
                    [u idx (bit-and 255 (aget a idx)) (bit-and 255 (aget b idx))])
                  previews (keep-indexed (fn [i a]
                                           (let [b (nth (:preview actual) i)]
                                             (when (not= a b) [i a b])))
                                         (:preview reference))]
              (spit (str (first *command-line-args*) ".mismatch")
                    (pr-str {:i n :lane lane :packet-count (count packet-deltas) :examples (vec (take 8 packet-deltas))
                             :preview (vec (take 2 previews)) :statuses (statuses hosts)}))
              (throw e))))))
    (doseq [^bytes packet (:packets reference)] (.update digest packet))
    (mapv (fn [lane] (assoc (get-in rows [lane :metrics]) :lane lane :i n)) (range 3))))

(defn record! [output pixels warmup samples budget]
  (let [{:keys [model preview-indices]} (#'venue/venue pixels)
        shapes (venue/volumes 4 #{:position :beam} 0.0)
        model (#'venue/seed-model (reduce add-wash (mixed-chart-model model) (range 8)) shapes)
        instances (into {} (map (juxt :cue-id :id)) (vals (:instances model)))
        ids (mapv #(instances (str "venue-field-" %)) (range 4))
        capacities [8 16 32]
        hosts (mapv #(open-host model budget %) capacities)
        counters (#'bench/worker-counters)
        digest (MessageDigest/getInstance "SHA-256")
        measure #(frame hosts ids preview-indices % counters digest)]
    (try
      (let [cold (measure 0)
            cold-status (statuses hosts)]
        (doseq [n (range 1 warmup)] (measure n))
        (let [before (statuses hosts) rows (mapv measure (range warmup (+ warmup samples)))]
          (spit output (pr-str {:heads pixels :movers 64 :capacities capacities :budget-ms budget
                                :warmup warmup :samples samples :cold cold :cold-status cold-status
                                :before before :rows rows :after (statuses hosts)
                                :artdmx-sha256 (.formatHex (HexFormat/of) (.digest digest))}))))
      (finally (doseq [{:keys [runtime]} hosts] (show/stop! runtime))))))
(let [[output warmup samples] *command-line-args*
      budget (parse-long (or (System/getenv "VENUE_GPU_MS") "2000"))]
  (try (record! (str output ".primer") 1000 3 1 budget)
       (record! output 20000 (parse-long warmup) (parse-long samples) budget)
       (finally (shutdown-agents))))
