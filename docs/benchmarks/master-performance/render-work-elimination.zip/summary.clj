(require '[clojure.edn :as edn])
(let [data (edn/read-string (slurp (first *command-line-args*)))
      ks [:ms :bytes :gc-pause-ms :main-cpu :runqueue :cpu-ms :tick :publish :preview]
      fmt #(Math/round (double %))]
  (prn (dissoc data :rows))
  (doseq [[lane rows] (sort-by key (group-by :lane (:rows data)))]
    (let [order (sort-by :ms rows) idx (fn [p] (dec (int (Math/ceil (* p (count rows)))))) p95 (nth order (idx 0.95))]
      (prn {:lane lane
            :median (into {} (map (fn [k] [k (fmt (nth (sort (map k rows)) (idx 0.5)))]) ks))
            :p95-frame (update-vals (select-keys p95 (conj ks :i)) fmt)
            :largest (mapv #(update-vals (select-keys % (conj ks :i)) fmt) (take-last 3 order))
            :zero-gc-frames (count (filter #(zero? (:gc-pause-ms %)) rows))}))))
