#!/usr/bin/env bash
set -euo pipefail
: "${TOLGLOW_ROOT:?Set TOLGLOW_ROOT to the absolute Tolglow checkout}"
: "${AFTERGLOW_ROOT:?Set AFTERGLOW_ROOT to the absolute Afterglow checkout}"
capture_dir="$(cd "$(dirname "$0")" && pwd)"
scenario="${1:?Choose cache, packed, uniform, isolated, precision, connected, optical-bound, or optical-bound-native}"
output="${2:?Supply an output EDN path}"
warmup="${3:-18}"
samples="${4:-24}"
case "$scenario" in
  cache|packed|uniform|isolated|precision|connected|optical-bound|optical-bound-native) ;;
  *) echo "Unknown replay $scenario" >&2; exit 2 ;;
esac
temp_classes="$(mktemp -d)"
trap 'rm -rf "$temp_classes"' EXIT
if [[ "$scenario" == optical-bound* ]]; then
  mkdir -p "$temp_classes/perf"
  base=d11a4c49824f137f0808bc95b4d20a746a8f6039
  git -C "$AFTERGLOW_ROOT" show "$base:src/afterglow/spatial/beam.clj" |
    sed -e 's/^(ns afterglow.spatial.beam$/(ns perf.original-beam/' \
        -e 's/::\(mounted\|prepared\|probe\)/:afterglow.spatial.beam\/\1/g' > "$temp_classes/perf/original_beam.clj"
  git -C "$AFTERGLOW_ROOT" show "$base:src/afterglow/spatial/field.clj" |
    sed -e 's/^(ns afterglow.spatial.field$/(ns perf.original-field/' \
        -e 's/afterglow.spatial.beam :as beam/perf.original-beam :as beam/' \
        -e 's/::\(emitters\|optics\)/:afterglow.spatial.field\/\1/g' > "$temp_classes/perf/original_field.clj"
fi
export AFTERGLOW_ROOT VENUE_MATERIAL_FILE="$capture_dir/replays/mixed-material.clj"
class_path="$(cd "$TOLGLOW_ROOT" && lein with-profile +benchmark,+native-gpu classpath)"
java -Xms1280m -Xmx1280m -XX:ActiveProcessorCount=3 -cp "$temp_classes:$class_path" \
  clojure.main "$capture_dir/replays/$scenario.clj" "$output" "$warmup" "$samples"
