# A one-shot’s final frame

This deterministic two-worker capture uses Tolglow
`524aabf5c4f189af27f7b6a0ffbb1c500fa03c11` and Afterglow
`74d0de46ec7dfd4d6985287c01989c9999b2990d`. Head 1 runs a one-beat ramp.
Head 2 emits white for the single frame at 225 ms. The in-memory sink records
the five dimmer, red, green, blue and white bytes per head. The plot derives
relative emission as dimmer × highest RGBW channel / 255. This is a packet
replay with 25 ms show-time steps. The animation plays those steps slowly for
inspection.

The EDN includes the instance outcome reported by the completed frame, raw calls
this render, lifetime calls while a governor entry exists, and the actual five
DMX bytes. At 225 ms the ramp emits 46 with no worker call. Head 2 emits 255 on
one call and retires. On the next step its DMX dimmer stays at 255 and its four
color channels fall to zero.

Extract the archive, set `evidence_dir` to its absolute directory, and run
the following from the checked-out Tolglow project. The paired Afterglow
checkout is in the sibling directory `../afterglow`.

```sh
AFTERGLOW_ROOT=../afterglow lein with-profile +benchmark run -m clojure.main \
  "$evidence_dir/capture-terminal.clj" "$evidence_dir"
python "$evidence_dir/draw-terminal.py" "$evidence_dir" "$evidence_dir"
```

The chart requires Pillow and the DejaVu Sans regular and bold fonts.
