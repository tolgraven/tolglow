(require '[clojure.java.io :as io] '[clojure.string :as str] '[tolglow.demo :as demo]
         '[tolglow.perf.effect-samples :as samples] '[tolglow.show :as show])

(defn install [model effect]
  (let [id (:id effect)]
    (-> model (assoc-in [:registry :effects id] effect)
        (assoc-in [:registry :cues id] {:id id :version 1 :effect-id id}))))

(let [output (io/file (or (first *command-line-args*) "target/terminal-frame"))
      _ (.mkdirs output)
      model (-> (demo/model)
                (install {:id :ramp :version 1 :targets [:head-1] :keyframes {:interval {:beats 1}}
                          :outputs {:color [1 1 1] :dimmer {:op :multiply :args [0.4 {:op :beat}]}}})
                (install {:id :one-shot :version 1 :targets [:head-2] :outputs {:color [1 1 1] :dimmer 1}}))
      sent (atom [])
      host (show/create-runtime {:model model :workers 2 :batch? true :workspace-options nil
                                 :adaptive-keyframes {:enabled? true :max-stride 1}
                                 :sink {:send! (fn [u id] (let [b ^bytes (get u 1)
                                                                 channels (fn [start] (mapv #(bit-and 255 (aget b (+ start %))) (range 5)))
                                                                 peak (fn [[d & emitters]] (Math/round (/ (* d (apply max emitters)) 255.0)))
                                                                 a (channels 0) b (channels 12)]
                                                             (swap! sent conj {:id id :ramp-channels a :shot-channels b
                                                                               :ramp (peak a) :shot (peak b)})))}})
      compile-step (:compile host)
      runtime (assoc host :capture-effect-samples? true
                     :compile (fn [definition] (let [step (compile-step definition)]
                                                 (if (= :one-shot (:id definition))
                                                   (fn [ctx] (assoc (step ctx) :done? true)) step))))]
  (try
    (let [ramp (show/submit! runtime {:op :cue/launch :cue-id :ramp})
          rows (mapv (fn [frame]
                       (let [at (* frame 25)]
                         (when (= 9 frame) (show/submit! runtime {:op :cue/launch :cue-id :one-shot}))
                         (show/tick! runtime at)
                         (let [state @(:state runtime)
                               obs (:effect-sampling (samples/capture {:ready-at-ms at} state))
                               ramp-sample (get obs (:instance-id @ramp))
                               shot (some (fn [[_ x]] (when (= :one-shot (:effect-id x)) x)) obs)]
                           (merge {:frame frame :time-ms at :beat (get-in state [:model :transport :beat])
                                   :ramp-sample ramp-sample :shot-sample shot} (last @sent))))) (range 25))]
      (assert (= 1 (count (filter :shot-sample rows))))
      (assert (= [:retired-sampled 1 255] ((juxt (comp :outcome :shot-sample)
                                                  (comp :calls-this-render :shot-sample) :shot) (rows 9))))
      (assert (every? #(zero? (:shot %)) (into (subvec rows 0 9) (subvec rows 10))))
      (spit (io/file output "terminal-frame.edn") (pr-str rows))
      (spit (io/file output "terminal-frame.tsv")
            (str/join "\n" (for [{:keys [frame time-ms beat ramp shot ramp-sample shot-sample]} rows]
                              (str/join "\t" [frame time-ms beat ramp shot (name (:outcome ramp-sample))
                                              (:calls-this-render ramp-sample) (or (:calls-this-render shot-sample) 0)]))))
      (prn {:frames (count rows) :shot (rows 9) :following (rows 10)}))
    (finally (show/stop! host))))
(shutdown-agents)
