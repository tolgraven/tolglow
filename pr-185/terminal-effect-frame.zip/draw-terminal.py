from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
from zipfile import ZipFile, ZIP_DEFLATED

source = Path('/tmp/pad-overlap')
assets = Path('/tmp/pr-visual-qa/assets')
rows = []
for line in (source/'terminal-frame.tsv').read_text().splitlines():
    frame, ms, beat, ramp, shot, outcome, rcalls, scalls = line.split('\t')
    rows.append(dict(frame=int(frame), ms=int(ms), ramp=int(ramp), shot=int(shot),
                     outcome=outcome, rcalls=int(rcalls), scalls=int(scalls)))
def font(size, bold=False):
    return ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans' + ('-Bold' if bold else '') + '.ttf', size)
bg, ink, muted, line = '#12202a', '#f1f6f7', '#b8c9d1', '#37505e'
ramp, shot, highlight = '#74d4bc', '#ffba78', '#eff4b1'
def draw(i):
    im = Image.new('RGB', (1060, 604), bg)
    d = ImageDraw.Draw(im)
    def text(x, y, content, size=17, color=ink, bold=False, anchor=None):
        d.text((x,y), content, font=font(size, bold), fill=color, anchor=anchor)
    text(32,21,'A one-shot’s final frame',33,ink,True)
    text(33,73,'Two effect workers  ·  25 samples at 40 Hz show time  ·  DMX-derived emission (0–255)',19,muted)
    last = len(rows)-1
    x = lambda k: 104 + k * (906 / last)
    y = lambda v: 330 - v * 148 / 255
    text(34,122,'Head 1  ·  one-beat ramp',19,ramp,True)
    text(485,122,'Head 2  ·  one-shot',19,shot,True)
    for v in [0,128,255]:
        d.line((100,y(v),1010,y(v)),fill=line,width=1)
        text(86,y(v),str(v),14,muted,anchor='rm')
    for k in range(0,last+1,4):
        d.line((x(k),174,x(k),335),fill=line,width=1)
        text(x(k),344,str(rows[k]['ms']),15,muted,anchor='mt')
    text(1010,369,'Show time (ms)',14,muted,anchor='rt')
    for key, color in [('ramp',ramp),('shot',shot)]:
        pts = []
        for j,r in enumerate(rows):
            if pts: pts.append((x(j),pts[-1][1]))
            pts.append((x(j),y(r[key])))
        d.line(pts,fill=color,width=3)
    d.line((x(i),168,x(i),333),fill=highlight,width=2)
    for key, color in [('ramp',ramp),('shot',shot)]:
        cy=y(rows[i][key]);d.ellipse((x(i)-5,cy-5,x(i)+5,cy+5),fill=color,outline=bg,width=1)
    curr=rows[i]
    text(33,390,f"Frame {curr['frame']}  ·  {curr['ms']} ms",23,highlight,True)
    text(33,435,f"Ramp     emission {curr['ramp']:3d}     {curr['rcalls']} worker call{'s' if curr['rcalls'] != 1 else ''}     {curr['outcome']}",19,ramp)
    shot_state = 'sampled and retired' if curr['scalls'] else 'inactive'
    text(33,468,f"One-shot     emission {curr['shot']:3d}     {curr['scalls']} worker call{'s' if curr['scalls'] != 1 else ''}     {shot_state}",19,shot)
    d.line((32,522,1025,522),fill=line,width=1)
    text(33,540,'At 225 ms the one-shot returns full brightness and leaves the active registry.',18,ink)
    text(33,568,'Emission = dimmer × strongest RGBW channel / 255. Captured at the in-memory sink.',16,muted)
    return im
draw(9).save(assets/'terminal-effect-frame.png')
frames=[draw(i) for i in range(len(rows))]
frames[0].save(assets/'terminal-effect-frame.gif',save_all=True,append_images=frames[1:],
              duration=[850 if i in [0,9,len(rows)-1] else 165 for i in range(len(rows))],loop=0,optimize=True)
with ZipFile(assets/'terminal-effect-frame.zip','w',ZIP_DEFLATED) as z:
    for f in ['capture-terminal.clj','terminal-frame.edn','terminal-frame.tsv','draw-terminal.py']:
        z.write(source/f,f)
