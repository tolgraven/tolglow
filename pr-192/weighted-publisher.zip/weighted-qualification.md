# Live mixed venue on the hosted Linux runners

`weighted-live-ubuntu-137855456375.edn` is the source of the diagram and animation. The show contains 20,000 RGBW pixels, 64 moving heads, four moving selection volumes using both position and beam membership, a mixed UV chart and eight washes. The file contains all 240 measured slots and surrounding warmup/drain observations. Tolglow c4d860a7081b12239a9b51c968dea69e87db4b21 and Afterglow 74d0de46ec7dfd4d6985287c01989c9999b2990d were measured at 40 Hz with two effect workers on a four-vCPU Ubuntu runner. All 240 encoded deliveries contained the 158 required universe payloads. 43 renders completed and none took 25 ms or less. Only 32 slots delivered the current source. The other 208 deliveries held an older frame. `weighted-live-ubuntu-137846982098.edn` is an earlier capture on a second Ubuntu runner. That earlier version counted payloads but did not check their individual lengths. `weighted-live-covered-smoke.edn` is an independent functional rehearsal on a contended shared host with only 64 pixels and all 64 moving heads.

To reproduce the capture, check out the revisions above into sibling tolglow and afterglow directories, then run from tolglow with JDK 21 and Leiningen:

```
AFTERGLOW_ROOT=../afterglow lein with-profile +benchmark run -m tolglow.perf.weighted-live target/live-weighted-venue.edn 20000 160 240
```

To rebuild the diagram from the recorded EDN, use Babashka and Python with Pillow and the DejaVu Sans fonts:

```
bb weighted-chart.clj weighted-live-ubuntu-137855456375.edn live.json
python3 weighted-chart.py live.json weighted-publisher
```

`:renders` records actual start, completed and ready times. `:outputs` records slot admission, driver entry, encoded handoff and return times, sampled input age, a lit RGBW pixel and the 64-head pan/tilt checksum. `:motion` covers the entire observed session including warmup. `:window-resources` covers JVM-wide allocation, process CPU and collection time during the measured six seconds. The in-memory driver uses the production ArtDMX encoder without emitting network traffic. The show stop blackout occurs after the captured window.
