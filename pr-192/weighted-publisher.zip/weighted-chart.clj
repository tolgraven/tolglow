(require '[clojure.edn :as edn] '[cheshire.core :as json])
(let [[src dest] *command-line-args*
      r (edn/read-string (slurp src))
      brief (fn [entry] {:slot (:slot entry) :ready-at-ms (:ready-at-ms entry) :cost-ms (:cost-ms entry)
                         :source (:source entry) :sink-at-ms (:sink-at-ms entry)
                         :first-head (get-in entry [:transport :aim :first-head-bytes])})]
  (spit dest (json/generate-string (-> r (dissoc :missed-wakes)
                                      (update :renders #(mapv brief %))
                                      (update :outputs #(mapv brief %))))))
