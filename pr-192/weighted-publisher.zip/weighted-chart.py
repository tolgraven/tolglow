from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import sys,json,math
s=Path(sys.argv[1]); target=Path(sys.argv[2]); r=json.loads(s.read_text())
summary=r['summary']; first,last=r['first-slot'],r['last-slot']; n=last-first+1
by=lambda key:{x['slot']:x for x in r[key]}
rr,oo=by('renders'),by('outputs')
def font(n,bold=False):return ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans'+('-Bold' if bold else '')+'.ttf',n)
bg='#101e27'; fg='#f5f8f8'; muted='#b3c4cd'; ready='#63d7b4'; held='#edbd74'; late='#f38b80'; missing='#314651'; older='#9cb4f9'; neutral='#718390'
palette={'current':ready,'held':held,'older':older,'idle':neutral,'late-delivery':late}
def draw(selected):
    height=600+max(0,math.ceil(n/40)-2)*52
    pic=Image.new('RGB',(1160,height),bg); d=ImageDraw.Draw(pic)
    def text(x,y,t,size,col=fg,b=False,**kw):d.text((x,y),str(t),fill=col,font=font(size,b),**kw)
    rig=r['rig']; total=f"{rig['pixels']:,} RGBW pixels and {rig['moving-heads']} moving heads"
    text(28,18,'Live ArtDMX publication',35,b=True)
    text(30,66,total+'   ·   four moving volumes   ·   eight washes   ·   40 Hz',20,muted)
    budget=summary['complete-within-25-ms']; complete=summary['completed-renders']
    text(30,112,f'{budget}/{n} slots produced a complete render in 25 ms',24,b=True)
    p=summary.get('completed-render-ms') or {}
    p95=p.get('p95')
    duration='—' if p95 is None else f'{p95:.2f} ms'
    text(30,151,f'{complete} completed renders   ·   start-to-ready p95 {duration}',18)
    counts=summary['source-counts']
    text(30,186,f"{counts.get('current',0)} current sources   ·   {counts.get('held',0)} held   ·   {summary['sent']} total encoded deliveries",20,ready)
    text(30,236,'Each column is one nominal 25 ms slot',20,b=True)
    text(32,270,'Time',15,muted)
    rows=math.ceil(n/40); x0=169; step=23.65
    for j in range(0,40,5):text(x0+j*step,270,f'+{j*25}',13,muted)
    text(1116,270,'ms',13,muted)
    for row in range(rows):
        y=301+row*52
        text(30,y,f'{row+1}s',18,fg,True)
        text(72,y,'Render',14,muted);text(72,y+18,'Output',14,muted)
        for j in range(40):
            slot=first+row*40+j
            if slot>last:break
            a=rr.get(slot) or {}; b=oo.get(slot) or {}
            rc=missing if a.get('ready-at-ms') is None else ready if a['cost-ms']<=25 else late
            oc=palette.get(b.get('source'),missing)
            x=x0+j*step
            d.rectangle((x,y+2,x+step-2,y+14),fill=rc)
            d.rectangle((x,y+20,x+step-2,y+32),fill=oc)
            if slot==selected:d.rectangle((x-1,y,x+step-1,y+34),outline='#f6f4b5',width=2)
    y=301+rows*52+9
    for x,col,t in [(30,ready,'≤25 ms / current'),(215,late,'slow / late'),(353,held,'held'),(443,older,'new older source'),(654,neutral,'idle'),(746,missing,'no ready render / no delivery')]:
        d.rectangle((x,y+4,x+13,y+17),fill=col);text(x+21,y,t,15)
    row=rr.get(selected) or {};output=oo.get(selected) or {}
    t='no completed render' if row.get('ready-at-ms') is None else f"{row['cost-ms']:.2f} ms to ready"
    u=output.get('source') or 'no transport handoff'
    text(30,y+46,f'Slot {selected}     {t}     ·     {u}',22,b=True)
    aim=output.get('first-head')
    text(31,y+85,'First head pan / tilt coarse and fine bytes   '+ (' '.join(f'{v:02X}' for v in aim) if aim else '—'),17,muted)
    poses=summary['distinct-volume-poses']
    text(31,y+117,f"Committed volume positions   {' / '.join(str(v) for v in poses)}     ·     Distinct delivered aim states   {summary['distinct-delivered-aim-states']}",17)
    text(31,y+154,'In-memory ArtDMX handoff. Animation steps through selected measured slots.',15,muted)
    return pic
focus=next((i for i in range(first,last+1) if (oo.get(i) or {}).get('source')=='held'),first)
draw(focus).save(str(target)+'.png')
sel=sorted({first,last,focus,*range(first,last+1,max(1,n//24))})
films=[draw(i) for i in sel]
films[0].save(str(target)+'.gif',save_all=True,append_images=films[1:],
              duration=[850 if i in (0,len(sel)-1) else 190 for i in range(len(sel))],loop=0,optimize=True)
